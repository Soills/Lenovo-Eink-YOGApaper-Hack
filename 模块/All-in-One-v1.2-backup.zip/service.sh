#!/system/bin/sh
# SP523FC All-in-One: 开机自动全开 (无开关, 每次开机强制执行)

# 1. 开发者选项 (入口 + Activity, global + secure 都写)
pm enable 'com.android.settings/com.android.settings.Settings$DevelopmentSettingsDashboardActivity' 2>/dev/null
pm enable 'com.android.settings/.Settings$DevelopmentSettingsDashboardActivity' 2>/dev/null
settings put global development_settings_enabled 1
settings put secure development_settings_enabled 1

# 2. ADB (USB + WiFi): 先切 none 再切 adb 强制触发, 并拉起 adbd
settings put global adb_enabled 1
setprop persist.sys.usb.config adb
setprop persist.adb.tcp.port 5555
setprop sys.usb.config none
setprop sys.usb.config adb
stop adbd 2>/dev/null
start adbd 2>/dev/null

# 3. 解除安装应用限制
settings put secure install_non_market_apps 1
settings put global package_verifier_enable 0
settings put global verifier_verify_adb_installs 0
settings put global verifier_disable_adb_installs 1
for pkg in $(pm list packages 2>/dev/null | sed 's/package://'); do
  appops set "$pkg" REQUEST_INSTALL_PACKAGES allow 2>/dev/null
done

# 4. 常用设置全开
settings put global stay_on_while_plugged_in 3
settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0
