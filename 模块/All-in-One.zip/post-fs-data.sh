#!/system/bin/sh
# SP523FC All-in-One post-fs-data
#
# 仅处理用户明确加入黑名单、且固件明确标记为可卸载的三个预装包。
# 不修改 /data/system/packages.xml 或 packages.list，不删除用户应用数据。
# 黑名单文件：/data/adb/modules/sp523fc_allinone/preload-blacklist
# 每行一个包名；使用 uninstall_preload.sh 添加。

MODDIR=${0%/*}
BLACKLIST="$MODDIR/preload-blacklist"
STATE=/data/system/users/0/package-restrictions.xml
BACK=/odm/bundled_uninstall_back-app
EMPTY="$MODDIR/.empty-preloads"

[ -r "$BLACKLIST" ] || exit 0
[ -r "$STATE" ] || exit 0
[ -d "$BACK" ] || exit 0
mkdir -p "$EMPTY" 2>/dev/null

hide_if_uninstalled() {
    PKG="$1"
    DIR="$2"
    TARGET="$BACK/$DIR"
    [ -d "$TARGET" ] || return 0

    # 只在 PM 已记录 user 0 为未安装时隐藏，默认不会影响预装包。
    grep -q "<pkg name=\"$PKG\"[^>]*installed=\"false\"" "$STATE" 2>/dev/null || return 0
    mkdir -p "$EMPTY/$DIR" 2>/dev/null
    mountpoint -q "$TARGET" 2>/dev/null || mount --bind "$EMPTY/$DIR" "$TARGET" 2>/dev/null
}

hide_if_uninstalled cnki.net.psmc TC421_ZhiWang
hide_if_uninstalled com.ophone.reader.ui TC421_CMRead_Eink
hide_if_uninstalled com.tencent.weread.eink TC421_WeChatReader
exit 0
