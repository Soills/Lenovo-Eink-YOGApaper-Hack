#!/system/bin/sh
# 永久隐藏联想可卸载预装包（不清 userdata、不改 /system）
# 用法：su -c 'sh /data/adb/modules/sp523fc_allinone/uninstall_preload.sh <包名>'
# 仅允许固件已知的 bundled_uninstall_back-app 包，避免误伤系统组件。

MODDIR=/data/adb/modules/sp523fc_allinone
BLACKLIST="$MODDIR/preload-blacklist"
PKG="$1"

case "$PKG" in
  cnki.net.psmc|com.ophone.reader.ui|com.tencent.weread.eink) ;;
  *) echo "不支持或不安全的预装包: $PKG"; exit 2 ;;
esac

mkdir -p "$MODDIR"
grep -qxF "$PKG" "$BLACKLIST" 2>/dev/null || echo "$PKG" >> "$BLACKLIST"
pm uninstall --user 0 "$PKG"
RC=$?
echo "已记录黑名单: $PKG (pm uninstall rc=$RC)"
exit $RC
