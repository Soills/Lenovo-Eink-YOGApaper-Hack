PiInstaller Unlocked v2.0
=========================

作用
----
替换系统自带 PackageInstaller（com.android.packageinstaller），移除两道安装门槛：
  1. 安装白名单（checkWhiteListApps，读 /system/etc/lenovoapps.xml + ro.boot.target.region）
  2. 未知来源 / REQUEST_INSTALL_PACKAGES appop 检查
保留：no_install_apps 管理员限制（MDM 策略，个人设备不会触发）。

v2.0 为什么是 Magisk 模块（重要）
--------------------------------
v1 用「删系统 APK + 重启清记录」的方式，实测在这台带开机自检的机器上触发进不去系统
（要整包重刷恢复）。v2 彻底换方案：

  * 不写 /system 磁盘文件 —— Magisk systemless 覆盖（内存挂载），原文件原封不动
  * 只动 /data —— 开机在 system_server 启动前，把 packages.xml 里该包的旧签名条目
    删掉（带备份 + 自校验，坏了自动还原），让 PM 以新签名重新登记覆盖版
  * 一次重启生效；回滚 = 卸载模块（Magisk 会自动清记录，原版重新登记）

安装（出厂包刷回后）
--------------------
1. 先刷 Magisk root boot（一键流程.cmd [1]），装好 Magisk 管理器并激活
2. 确认 Magisk 已给 shell 授权（Magisk → 超级用户 → 批准 Shell）
3. bash install_unlocked.sh   —— 自动：构建模块 → 装入 /data/adb/modules → 重启 → 校验
4. 校验通过后任意 APK 点开直接装

回滚
----
bash install_unlocked.sh uninstall   （清记录 + 移除模块，重启后恢复原版）
或用 Magisk 管理器移除本模块（会自动执行 uninstall.sh 清记录）。
